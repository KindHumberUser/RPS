# RockPaperScissors2 > 2023-11-13 6:02pm
https://universe.roboflow.com/virginia-tech-smbuc/rockpaperscissors2-2ba5y

Provided by a Roboflow user
License: CC BY 4.0

